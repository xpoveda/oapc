import { NgModule }                    from '@angular/core';
import { BrowserModule }               from '@angular/platform-browser';
import { FormsModule }                 from '@angular/forms';
import { HttpClientModule }            from '@angular/common/http';

import { BsDropdownModule }            from 'ngx-bootstrap/dropdown';

import { AppComponent }                 from './app.component';
import { AppRoutingModule }             from './app-routing.module';

import { PaginaPrincipalComponent }     from './pagina-principal/pagina-principal.component';
import { PaginaNoEncontradaComponent }  from './pagina-no-encontrada/pagina-no-encontrada.component';
import { AgendaComponent }              from './agenda/agenda.component';

@NgModule({
  imports: [
    BsDropdownModule.forRoot(),
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  declarations: [
    AppComponent,
    PaginaPrincipalComponent,
    PaginaNoEncontradaComponent,
    AgendaComponent
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }