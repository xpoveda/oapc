import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { PaginaPrincipalComponent }    from './pagina-principal/pagina-principal.component';
import { PaginaNoEncontradaComponent } from './pagina-no-encontrada/pagina-no-encontrada.component';
import { AgendaComponent }             from './agenda/agenda.component';


const routes: Routes = [
  { path: '',           component: PaginaPrincipalComponent },
  { path: 'agenda',     component: AgendaComponent },
  { path: '**',         component: PaginaNoEncontradaComponent },  
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}