import { Injectable } from '@angular/core';

@Injectable()
export class TalkService {


  constructor() { 
  }

  public getAllTalks() {

    return  [
              {titulo : "PRIMERO",  nombre : "XAVIER"},
              {titulo : "SEGUNDO",  nombre : "ADRIAN"},
              {titulo : "TERCERO",  nombre : "AITANA"}
            ];
  }
}

