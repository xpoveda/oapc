import { Component, OnInit } from '@angular/core';

import { TalkService } from './../talk.service';

// MODO 3
import {Http} from '@angular/http';
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-talks',
  templateUrl: './talks.component.html',
  styleUrls:  ['./talks.component.css']
})
export class TalksComponent implements OnInit {


  // MODO 1: TALKS HARDCODEADO DIRECTAMENTE EN COMPONENTE
  //talks: string[]= ['a','b','d','e'];

  //talks :  Array<any> = [
  //                            {titulo : "PRIMERO",  nombre : "XAVIER"},
  //                            {titulo : "SEGUNDO",  nombre : "ADRIAN"},
  //                            {titulo : "TERCERO",  nombre : "AITANA"}
  //                      ];

  //constructor() { 
  //    console.log("Contenido de talks:");
  //    console.log(this.talks);
  // }

  // MODO 2: TALKS ACCEDE A SERVICIO CON DATOS HARDCODEADOS
  // talks;

  // constructor(private talkservice: TalkService) { 
  // this.talks = talkservice.getAllTalks();
  // console.log(this.talks);
  // }

  // MODO 3: TALKS ACCESO HTTP

  talks;

  constructor(private talkservice: TalkService, http: Http) { 
    this.talks = talkservice.getAllTalks();
    console.log(this.talks);

    //http
    //  .get('https://data-agenda.wedeploy.io/talks')
    //  .subscribe( x => console.log(x));

    //http
    //  .get('https://data-agenda.wedeploy.io/talks')
    //  .map(x => x.json())
    //  .subscribe( x => console.log(x));

      http
      .get('https://data-agenda.wedeploy.io/talks')
      .map(x => x.json())
      .subscribe( x => this.talks = x);
  }

  ///////////////////////////////////////////////////////////////////

  ngOnInit() {
    //console.log(this.talks);
  }

  onclick($event) {
    console.log("CAPTURADO CLICK EN TALKS");
    console.log($event);
  }

  log($event){
    console.log("talks, capturado evento:" + $event)
  }

}