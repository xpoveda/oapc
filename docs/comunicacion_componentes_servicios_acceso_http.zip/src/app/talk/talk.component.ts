import { Component, Input, Output, OnInit, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-talk',
  templateUrl:'./talk.component.html',
  styleUrls: ['./talk.component.css']
})
export class TalkComponent implements OnInit {

  @Input()  talk;
  @Output() talkClicked: EventEmitter<any> = new EventEmitter();

  constructor() { }

  ngOnInit() {
  }

  onclick($event)
  {
    console.log("CAPTURADO CLICK EN TALK Y LO TRASPASAMOS A TALKS");
    this.talkClicked.emit(this.talk);
  }


}
