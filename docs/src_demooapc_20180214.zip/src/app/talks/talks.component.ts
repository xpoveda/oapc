import { Component, OnInit } from '@angular/core';

import { TalkService } from './../talk.service';

import {Http} from '@angular/http';
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-talks',
  templateUrl: './talks.component.html',
  styleUrls:  ['./talks.component.css']
})
export class TalksComponent implements OnInit {

  talks;

  constructor(private talkservice: TalkService, http: Http) { 
    this.talks = talkservice.getAllTalks();
    console.log(this.talks);

    //http
    //  .get('https://data-agenda.wedeploy.io/talks')
    //  .subscribe( x => console.log(x));

    //http
    //  .get('https://data-agenda.wedeploy.io/talks')
    //  .map(x => x.json())
    //  .subscribe( x => console.log(x));

      http
      .get('https://data-agenda.wedeploy.io/talks')
      .map(x => x.json())
      .subscribe( x => this.talks = x);
  }

  ///////////////////////////////////////////////////////////////////

  ngOnInit() {
    //console.log(this.talks);
  }

  onclick($event) {
    console.log("CAPTURADO CLICK EN TALKS");
    console.log($event);
  }

  log($event){
    console.log("talks, capturado evento:" + $event)
  }

}