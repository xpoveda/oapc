import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { PaginaPrincipalComponent }    from './pagina-principal/pagina-principal.component';
import { PaginaPrincipal2Component }   from './pagina-principal2/pagina-principal2.component';
import { PaginaPrincipal3Component }   from './pagina-principal3/pagina-principal3.component';
import { PaginaLoginComponent }        from './pagina-login/pagina-login.component';
import { PaginaNoEncontradaComponent } from './pagina-no-encontrada/pagina-no-encontrada.component';

import { TalksComponent }              from './talks/talks.component';

const routes: Routes = [
  { path: '',           component: PaginaPrincipalComponent    },
  { path: 'pagina2',    component: PaginaPrincipal2Component   },
  { path: 'pagina3',    component: PaginaPrincipal3Component   }, 
  { path: 'login',      component: PaginaLoginComponent        }, 
  { path: 'talks',      component: TalksComponent              }, 
  { path: '**',         component: PaginaNoEncontradaComponent },  
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}