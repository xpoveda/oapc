import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagina-principal2',
  templateUrl: './pagina-principal2.component.html',
  styleUrls: ['./pagina-principal2.component.css']
})
export class PaginaPrincipal2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
