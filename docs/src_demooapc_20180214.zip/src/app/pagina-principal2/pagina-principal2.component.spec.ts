import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaginaPrincipal2Component } from './pagina-principal2.component';

describe('PaginaPrincipal2Component', () => {
  let component: PaginaPrincipal2Component;
  let fixture: ComponentFixture<PaginaPrincipal2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaginaPrincipal2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaginaPrincipal2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
