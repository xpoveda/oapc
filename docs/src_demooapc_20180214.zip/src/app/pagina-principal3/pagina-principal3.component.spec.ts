import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaginaPrincipal3Component } from './pagina-principal3.component';

describe('PaginaPrincipal3Component', () => {
  let component: PaginaPrincipal3Component;
  let fixture: ComponentFixture<PaginaPrincipal3Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaginaPrincipal3Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaginaPrincipal3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
