import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagina-principal3',
  templateUrl: './pagina-principal3.component.html',
  styleUrls: ['./pagina-principal3.component.css']
})
export class PaginaPrincipal3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
