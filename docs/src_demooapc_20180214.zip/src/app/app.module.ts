///////////////////////////////////////////////////////////////////////////////

import { NgModule }                    from '@angular/core';
import { BrowserModule }               from '@angular/platform-browser';
import { HttpClientModule }            from '@angular/common/http';
import { HttpModule }                  from '@angular/http';
import { FormsModule }                 from '@angular/forms';

///////////////////////////////////////////////////////////////////////////////

import { CollapseModule }              from 'ngx-bootstrap';
import { BsDropdownModule }            from 'ngx-bootstrap';

///////////////////////////////////////////////////////////////////////////////

import { AppComponent }                from './app.component';
import { AppRoutingModule }            from './app-routing.module';

///////////////////////////////////////////////////////////////////////////////

import { HeaderComponent }             from './header/header.component';
import { FooterComponent }             from './footer/footer.component';
import { MenuComponent }               from './menu/menu.component';

///////////////////////////////////////////////////////////////////////////////

import { PaginaPrincipalComponent }    from './pagina-principal/pagina-principal.component';
import { PaginaPrincipal2Component }   from './pagina-principal2/pagina-principal2.component';
import { PaginaPrincipal3Component }   from './pagina-principal3/pagina-principal3.component';
import { PaginaLoginComponent }        from './pagina-login/pagina-login.component';
import { PaginaNoEncontradaComponent } from './pagina-no-encontrada/pagina-no-encontrada.component';

///////////////////////////////////////////////////////////////////////////////

import { TalksComponent }              from './talks/talks.component';
import { TalkComponent }               from './talk/talk.component';

///////////////////////////////////////////////////////////////////////////////

import { TalkService }                 from './talk.service';

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

@NgModule({

  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    HttpModule,
    FormsModule,
    CollapseModule.forRoot(),
    BsDropdownModule.forRoot()
  ],

  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    MenuComponent,
    PaginaPrincipalComponent,
    PaginaPrincipal2Component,
    PaginaPrincipal3Component,
    PaginaLoginComponent,
    PaginaNoEncontradaComponent,
    TalksComponent,
    TalkComponent
  ],

  providers: [TalkService],

  bootstrap: [AppComponent]
})

///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

export class AppModule { }