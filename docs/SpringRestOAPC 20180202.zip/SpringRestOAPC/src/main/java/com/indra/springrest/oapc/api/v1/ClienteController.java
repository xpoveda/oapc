package com.indra.springrest.oapc.api.v1;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.indra.springrest.oapc.model.Cliente;
import com.indra.springrest.oapc.model.ErrorRest;
import com.indra.springrest.oapc.repo.ClienteRepository;

@RestController
@RequestMapping("/api/v1")
public class ClienteController {

	@Autowired
	ClienteRepository clienteRepository;

	@GetMapping("/clientes")
	public List<Cliente> list() {
		List<Cliente> result = clienteRepository.findAll();
		if (result != null)
			return result;
		else
			throw new ClienteNotFoundException();
	}

	@GetMapping("/cliente/{id}")
	public Cliente getCliente(@PathVariable Long id) {
		Cliente result = clienteRepository.findOne(id);
		if (result != null)
			return result;
		else
			throw new ClienteNotFoundException(id);
	}
		
	@PostMapping("/cliente")
	public ResponseEntity<?> createCliente(RequestEntity<Cliente> reqCliente) {
		
		if (reqCliente.getBody() == null) {
			return new ResponseEntity<ErrorRest>(new ErrorRest("Formato de petición incorrecto. Debe enviar los datos del cliente a dar de alta"),
					HttpStatus.BAD_REQUEST);
		}
		
		Cliente cliente = reqCliente.getBody();

		if (clienteRepository.findOne(cliente.getId()) != null) {
			return new ResponseEntity<ErrorRest>(new ErrorRest("El cliente con ID " + cliente.getId() + " ya existe"),
					HttpStatus.CONFLICT);
		} else {
			return new ResponseEntity<Cliente>(clienteRepository.save(cliente), HttpStatus.CREATED);
		}
	}

	@PutMapping("/cliente/{id}")
	public ResponseEntity<?> updateCliente(@PathVariable Long id, RequestEntity<Cliente> reqCliente) {
		
		if (reqCliente.getBody() == null) {
			return new ResponseEntity<ErrorRest>(new ErrorRest("Formato de petición incorrecto. Debe enviar los datos del cliente a modificar"),
					HttpStatus.BAD_REQUEST);
		}
		
		if (clienteRepository.findOne(id) != null) {
			Cliente cliente = reqCliente.getBody();
			Cliente aActualizar = new Cliente(id, cliente.getNombre(), cliente.getApellidos(), cliente.getFechaNacimiento());
			return new ResponseEntity<Cliente>(clienteRepository.save(aActualizar), HttpStatus.OK);
		} else {
			return new ResponseEntity<ErrorRest>(new ErrorRest("El cliente a modificar no existe"),
					HttpStatus.NOT_FOUND);
		}
		
	}

	@DeleteMapping("/cliente/{id}")
	public ResponseEntity<?> deleteCliente(@PathVariable Long id) {
		
		Cliente aBorrar = clienteRepository.findOne(id);
		if (aBorrar != null) {
			clienteRepository.delete(aBorrar);
			return new ResponseEntity<Cliente>(aBorrar, HttpStatus.OK);
		} else {
			return new ResponseEntity<ErrorRest>(new ErrorRest("El cliente a borrar no existe"),
					HttpStatus.NOT_FOUND);
		}
		
	}

	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	private class ClienteNotFoundException extends RuntimeException {

		private static final long serialVersionUID = 7295910574475009536L;

		public ClienteNotFoundException() {
			super("No existe ningún cliente");
		}

		public ClienteNotFoundException(Long id) {
			super(String.format("No existe ningún cliente con el ID = %d", id));
		}

	}

}
