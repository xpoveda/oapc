package com.indra.springrest.oapc.api.v1;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;

import com.indra.springrest.oapc.model.Usuario;
import com.indra.springrest.oapc.repo.UsuarioRepository;
import com.indra.springrest.oapc.model.ErrorRest;

@RestController
@RequestMapping("/api/v1")
public class UsuarioController {
	
	private final Logger logger = LoggerFactory.getLogger(UsuarioController.class);
	

	@Autowired
	UsuarioRepository usuarioRepository;
	
	private final InMemoryUserDetailsManager inMemoryUserDetailsManager;
	
    @Autowired
    public UsuarioController(InMemoryUserDetailsManager inMemoryUserDetailsManager) {
       this.inMemoryUserDetailsManager = inMemoryUserDetailsManager;
    }
	
	@GetMapping("/usuarios")
	public List<Usuario> list() {
		List<Usuario> result = usuarioRepository.findAll();
		if (result != null)
			return result;
		else
			throw new UsuarioNotFoundException();
	}
	
	@PostMapping("/login")
	public ResponseEntity<?> ValidarUsuario(
			RequestEntity<Usuario> reqUsuario,
			@RequestHeader(value="Authorization") String autorizacion) 
	{
		logger.info("ENTRADA LOGIN");
		
		logger.info("AUTORIZACION[" + autorizacion + "]");
		
		if (reqUsuario.getBody() == null) {
			return new ResponseEntity<ErrorRest>(new ErrorRest("Formato de petición incorrecto. Debe enviar los datos del cliente a modificar"),
					HttpStatus.BAD_REQUEST);
		}
		
		Usuario usuario_req  = reqUsuario.getBody();		
		Usuario usuario_bbdd = usuarioRepository.findOne(usuario_req.getEmail());
		
		if (usuario_bbdd != null) {
		    		    
			logger.info("USUARIO ENCONTRADO");
			
		    logger.info("REQUEST: " + usuario_req.getEmail()  + " " + usuario_req.getHash());		    		   
		    logger.info("BBDD   : " + usuario_bbdd.getEmail() + " " + usuario_bbdd.getHash());
		    
		    if (usuario_req.getHash().equals(usuario_bbdd.getHash()))
		    {		    	
		    	inMemoryUserDetailsManager.createUser(User.withUsername("xpoveda@indra.es").password("flash2009").roles("USER").build());
		    	logger.info("Añadido mecanismo de seguridad..");
		    }
		   		    		    		  		   		   		   
			return new ResponseEntity<Usuario>(usuario_bbdd, HttpStatus.OK);
		} 
		else 
		{			
			logger.info("USUARIO NO ENCONTRADO");
						
			return new ResponseEntity<ErrorRest>(new ErrorRest("Usuario no existe"),
					HttpStatus.NOT_FOUND);
		}	
	}
			
	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	private class UsuarioNotFoundException extends RuntimeException {

		private static final long serialVersionUID = 7295910574475009536L;

		public UsuarioNotFoundException() {
			super("No existe ningún Usuario");
		}
	}
	
}