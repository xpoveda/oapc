package com.indra.springrest.oapc.dataloaders;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
 
import com.indra.springrest.oapc.dataloaders.DataLoader;
import com.indra.springrest.oapc.model.Empleado;
import com.indra.springrest.oapc.repo.EmpleadoRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
 
@Component
@Order(2)
public class DataLoaderEmpleado implements CommandLineRunner {
 
    private final Logger logger = LoggerFactory.getLogger(DataLoader.class);
     
    EmpleadoRepository empleadoRepository;               
 
    public DataLoaderEmpleado(EmpleadoRepository empleadoRepository) {
        this.empleadoRepository = empleadoRepository;
    }
 
    @Override
    public void run(String... args) throws Exception {
    	
        logger.info("Cargando empleados...");
        
		String[][] data = {
				{"Xavier", "García Martínez", "01/01/1975"},
				{"Manuel", "Pérez Díaz", "10/10/1978"},
				{"Luis Miguel", "López Magaña", "18/09/1982"},
				{"Alberto", "Jiménez Sarmiento", "03/03/1973"},
				{"Carlos", "Ruiz Santos", "02/12/1978"},
				{"Martín", "López Alfaro", "04/05/1976"},
				{"María", "Martínez Sánchez", "14/07/1983"},
				{"Luisa", "Milán Llanes", "28/08/1978"}
		};
		
		final DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		
		
	      for (int i=0;i<data.length;i++){
	    	  	empleadoRepository.save(new Empleado(data[i][0], data[i][1], df.parse(data[i][2])));
	        }				
    }
 
}