package com.indra.springrest.oapc.dataloaders;
 
import com.indra.springrest.oapc.dataloaders.DataLoader;
import com.indra.springrest.oapc.model.Usuario;
import com.indra.springrest.oapc.repo.UsuarioRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
 
@Component
@Order(3)
public class DataLoaderUsuario implements CommandLineRunner {
 
    private final Logger logger = LoggerFactory.getLogger(DataLoader.class);
     
    UsuarioRepository usuarioRepository;               
 
    public DataLoaderUsuario(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }
 
    @Override
    public void run(String... args) throws Exception {
    	
        logger.info("Cargando usuario...");
        
		String[][] data = {
				{"xpoveda@gmail.com", "flash2009"},
				{"xpoveda@indra.es",  "indra.8888"}
		};
				
	      for (int i=0;i<data.length;i++){
	    	  	usuarioRepository.save(new Usuario(data[i][0], data[i][1],""));
	        }				
    }
 
}