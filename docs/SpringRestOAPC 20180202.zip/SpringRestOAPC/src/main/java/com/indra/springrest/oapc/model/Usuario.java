package com.indra.springrest.oapc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Usuario {
	
	@Id
	@Column
	private String email;
	
	@Column
	private String hash;
	
	@Column
	private String clave_seguridad;

				
	public Usuario() {}


	public Usuario(long id, String email, String hash, String clave_seguridad) {
		this.email = email;
		this.hash = hash;
		this.clave_seguridad = clave_seguridad;		
	}
	
	public Usuario(String email, String hash, String clave_seguridad) {
		this.email = email;
		this.hash = hash;
		this.clave_seguridad = clave_seguridad;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getHash() {
		return hash;
	}


	public void setHash(String hash) {
		this.hash = hash;
	}
	
	public String getClaveSeguridad() {
		return clave_seguridad;
	}


	public void setClaveSeguridad(String clave_seguridad) {
		this.clave_seguridad = clave_seguridad;
	}	

	@Override
	public int hashCode() {
		
		final int prime = 31;
		int result = 1;
		
		result = prime * result + ((hash == null) ? 0 : hash.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		
		if (this == obj)
			return true;
		
		if (obj == null)
			return false;
		
		if (getClass() != obj.getClass())
			return false;
		
		Usuario other = (Usuario) obj;
				
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		
		if (hash == null) { 
			if (other.hash != null)
				return false;
		} else if (!hash.equals(other.hash))
			return false;
					
		return true;
	}
}
