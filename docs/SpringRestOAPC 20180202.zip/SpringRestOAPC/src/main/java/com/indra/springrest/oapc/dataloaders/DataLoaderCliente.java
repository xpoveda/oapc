package com.indra.springrest.oapc.dataloaders;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
 
import com.indra.springrest.oapc.dataloaders.DataLoader;
import com.indra.springrest.oapc.model.Cliente;
import com.indra.springrest.oapc.repo.ClienteRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
 
@Component
@Order(1)
public class DataLoaderCliente implements CommandLineRunner {
 
    private final Logger logger = LoggerFactory.getLogger(DataLoader.class);
     
    ClienteRepository clienteRepository;               
 
    public DataLoaderCliente(ClienteRepository clienteRepository) {
        this.clienteRepository = clienteRepository;
    }
 
    @Override
    public void run(String... args) throws Exception {
    	
        logger.info("Cargando clientes...");
        
		String[][] data = {
				{"cliente uno", "UNO", "01/01/1975"},
				{"cliente dos", "DOS", "10/10/1978"},
				{"cliente tres", "TRES", "10/10/1978"}
		};
		
		final DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		
		
	      for (int i=0;i<data.length;i++){
	    	  	clienteRepository.save(new Cliente(data[i][0], data[i][1], df.parse(data[i][2])));
	        }				
    }
 
}