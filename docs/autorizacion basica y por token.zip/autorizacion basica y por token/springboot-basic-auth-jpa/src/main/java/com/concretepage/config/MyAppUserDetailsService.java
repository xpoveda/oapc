package com.concretepage.config;

import java.util.Arrays;

import org.apache.log4j.Logger;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.concretepage.dao.IUserInfoDAO;
import com.concretepage.entity.UserInfo;

// Cada vez que llega una peticion al API, SPRING evalua que el usuario y password que nos llegue en el Header sea correcto.
// Se hace notar que cuando un usuario se ha autentificado correctamente en navegador se cacheará ese header.
// No tendria que ser asi si las llamadas son via java, curl o angular.

@Service
public class MyAppUserDetailsService implements UserDetailsService {
	@Autowired
	private IUserInfoDAO userInfoDAO;
	@Override
	public UserDetails loadUserByUsername(String userName)
			throws UsernameNotFoundException {
		
		Logger log = Logger.getLogger(MyAppUserDetailsService.class.getName());
		
		// El username y password se encapsula en el Header con la key "Authorization" en un encode64.
		// A loaduserbyusername SPRING lo informa con ese username
		
	    	//String credential="mukesh:m123";
	    	//String credential="tarun:t123";
	    	//String encodedCredential = new String(Base64.encodeBase64(credential.getBytes()));
	    //    HttpHeaders headers = new HttpHeaders();
	    //    headers.setContentType(MediaType.APPLICATION_JSON);
	    //    headers.add("Authorization", "Basic " + encodedCredential);
	    	//return headers;
		
		log.info("CARGANDO DEFINICION SECURITY CONFIG USUARIO " + userName);  
		
		// Lectura del usuario, password y rol de la BBDD yendo por username
		
		UserInfo activeUserInfo = userInfoDAO.getActiveUser(userName);
		GrantedAuthority authority = new SimpleGrantedAuthority(activeUserInfo.getRole());
		log.info("LECTURA BBDD: " + activeUserInfo.getUserName() + " " + activeUserInfo.getPassword() + " " +  activeUserInfo.getRole());
		
		// Creamos el usuario aue inyectaremos a la seguridad de SPRING con los datos de BBDD.
		// Si el username y el password que pasamos por el Header no coinciden con el de BBDD dará error.
		// En BBDD la contraseña es la que nos ha llegado con un encode64 ademas se le aplica una funcion de hash BCryptPasswordEncoder
		UserDetails userDetails = (UserDetails) new User(activeUserInfo.getUserName(),
				                                         activeUserInfo.getPassword(), 
				                                         Arrays.asList(authority));
		return userDetails;
	}
}

