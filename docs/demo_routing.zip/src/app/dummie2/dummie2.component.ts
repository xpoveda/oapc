import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dummie2',
  templateUrl: './dummie2.component.html',
  styleUrls: ['./dummie2.component.css']
})
export class Dummie2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
