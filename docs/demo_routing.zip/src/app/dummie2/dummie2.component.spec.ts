import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Dummie2Component } from './dummie2.component';

describe('Dummie2Component', () => {
  let component: Dummie2Component;
  let fixture: ComponentFixture<Dummie2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Dummie2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Dummie2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
