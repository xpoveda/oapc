import { Component }       from '@angular/core';
import { BrowserModule }   from '@angular/platform-browser';

import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls:  ['./app.component.css']
})
export class AppComponent {
  titulo  = 'Siempre llamamos a AppComponent';
  titulo2 = `Ponemos los selectores app-header y app-footer`; 
}
