import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { Dummie1Component }            from './dummie1/dummie1.component';
import { Dummie2Component }            from './dummie2/dummie2.component';
import { PaginaPrincipalComponent }    from './pagina-principal/pagina-principal.component';
import { PaginaNoEncontradaComponent } from './pagina-no-encontrada/pagina-no-encontrada.component';

const routes: Routes = [
  { path: '',           component: PaginaPrincipalComponent },
  { path: 'dummie1',    component: Dummie1Component },
  { path: 'dummie2',    component: Dummie2Component },
  { path: '**',         component: PaginaNoEncontradaComponent },  
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}