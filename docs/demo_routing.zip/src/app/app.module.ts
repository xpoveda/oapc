import { NgModule }                    from '@angular/core';
import { BrowserModule }               from '@angular/platform-browser';
import { FormsModule }                 from '@angular/forms';
import { HttpClientModule }            from '@angular/common/http';

import { AppComponent }                from './app.component';
import { AppRoutingModule }            from './app-routing.module';

import { HeaderComponent }             from './header/header.component';
import { FooterComponent }             from './footer/footer.component';

import { Dummie1Component }            from './dummie1/dummie1.component';
import { Dummie2Component }            from './dummie2/dummie2.component';

import { PaginaPrincipalComponent }    from './pagina-principal/pagina-principal.component';
import { PaginaNoEncontradaComponent } from './pagina-no-encontrada/pagina-no-encontrada.component';

@NgModule({
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    Dummie1Component,
    Dummie2Component,
    PaginaPrincipalComponent,
    PaginaNoEncontradaComponent
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
