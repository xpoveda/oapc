import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dummie1',
  template: `<p> DUMMIE1 CONTENEDOR </p>
  `,
  styleUrls: ['./dummie1.component.css']
})
export class Dummie1Component implements OnInit {

  titulo;

  constructor() { }

  ngOnInit() {
     this.titulo = "VARIABLE CARGADA ngOnInit"

  }

}
