export interface NotesResponse {
    id: number;
    title: string;
    content: string;
}
