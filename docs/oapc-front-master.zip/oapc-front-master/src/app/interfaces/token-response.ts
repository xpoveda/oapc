
export interface TokenResponse {
    access_token: string;
    expires_in: number;
}