
```                                                                           
  _________  ______   ____             ______ ______________  __ ___________ 
 /  _ \__  \ \____ \_/ ___\   ______  /  ___// __ \_  __ \  \/ // __ \_  __ \
(  <_> ) __ \|  |_> >  \___  /_____/  \___ \\  ___/|  | \/\   /\  ___/|  | \/
 \____(____  /   __/ \___  >         /____  >\___  >__|    \_/  \___  >__|   
           \/|__|        \/               \/     \/                 \/       

```



* Descarga del proyecto
* Definicion del "build path" con "jdk 1.8"
* make install

En Spring tool suite Windows\Show view y a�adir "Git repositories" y "Git staging".
Para subir los cambios directamente con "git shell" desde msdos o con "Git staging" moviendo los elementos a la "stage" y haciendo un "commit" cuando se crea necesario.

Tener abierto mysql de XAMPP.




